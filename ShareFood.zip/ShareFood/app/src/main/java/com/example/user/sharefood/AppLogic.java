package com.example.user.sharefood;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class AppLogic extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_logic);

        //final TextView helloText = findViewById(R.id.helloText);
       // helloText.setText("Hello " + getIntent().getStringExtra("userName"));

        Button sharePhotoBTN , shareRecipesBTN , searchRestaurantBTN , tellYourFriendsBTN , setTimerBTN ;

        sharePhotoBTN = findViewById(R.id.btn_shareFoodPhoto);
        shareRecipesBTN = findViewById(R.id.btn_shareRecipes);
        searchRestaurantBTN = findViewById(R.id.btn_restaurantSearch);
        tellYourFriendsBTN = findViewById(R.id.btn_tell_your_friends);
        setTimerBTN = findViewById(R.id.btn_set_timer);


        sharePhotoBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentSharePhoto = new Intent(AppLogic.this, SharePhoto.class);
                startActivity(intentSharePhoto);
            }
        });
        shareRecipesBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentShareRecipes = new Intent(AppLogic.this, ShareRecipes.class);
                startActivity(intentShareRecipes);
            }
        });
        searchRestaurantBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentSearchRestaurant = new Intent(AppLogic.this, SearchRestaurant.class);
                startActivity(intentSearchRestaurant);
            }
        });
        tellYourFriendsBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentTellYourFriendsBTN = new Intent(AppLogic.this, TellYourFriends.class);
                startActivity(intentTellYourFriendsBTN);
            }
        });
        setTimerBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentSetAlarm = new Intent(AppLogic.this, SetAlarm.class);
                startActivity(intentSetAlarm);
            }
        });
    }
}
