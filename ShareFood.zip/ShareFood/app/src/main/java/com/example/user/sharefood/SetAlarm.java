package com.example.user.sharefood;

import android.content.Intent;
import android.provider.AlarmClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SetAlarm extends AppCompatActivity {

    Button setAlarm;
    EditText hour, msg, minutes;
    String messageTxt;
    Integer hour_INT , minutes_INT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_alarm);

        setAlarm = findViewById(R.id.btn_create_alarm);
        hour = findViewById(R.id.txt_hour);
        minutes = findViewById(R.id.txt_minutes);

        msg = findViewById(R.id.text_alarm);


        setAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createAlarm();
            }
        });
    }

    public void createAlarm() {

        messageTxt = msg.getText().toString();
        hour_INT = Integer.parseInt(hour.getText().toString());
        minutes_INT = Integer.parseInt(minutes.getText().toString());

        Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_MESSAGE, messageTxt)
                .putExtra(AlarmClock.EXTRA_HOUR, hour_INT)
                .putExtra(AlarmClock.EXTRA_MINUTES, minutes_INT);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }
}
