package com.example.user.sharefood;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class TellYourFriends extends AppCompatActivity {
    EditText msg ;
    Button sendMsgBTN;
    String SMS_Body ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tell_your_friends);

        msg = findViewById(R.id.text_msg);
        sendMsgBTN = findViewById(R.id.btn_message);



        sendMsgBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SMS_Body = msg.getText().toString();
                Uri uri = Uri.parse("smsto:");
                Intent it = new Intent(Intent.ACTION_SENDTO, uri);
                it.putExtra("sms_body", SMS_Body);
                startActivity(it);
            }
        });
    }
}
