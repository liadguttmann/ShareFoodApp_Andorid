package com.example.user.sharefood;

import android.app.SearchManager;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SearchRestaurant extends AppCompatActivity {
    Button web , address;
    EditText text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_restaurant);

        web = findViewById(R.id.btn_search_restaurant);
        address= findViewById(R.id.btn_find_restaurant);
        text = findViewById(R.id.text_to_search);

        web.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              String webToSearch;
              webToSearch = text.getText().toString();
                searchWeb(webToSearch);
            }
        });
        address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String addressSTR = text.getText().toString();
                String format = "geo:0,0?q="+addressSTR;
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(format));
                startActivity(intent);
            }
        });
    }

    public void searchWeb(String query) {
        Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);
        intent.putExtra(SearchManager.QUERY, query);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

}
