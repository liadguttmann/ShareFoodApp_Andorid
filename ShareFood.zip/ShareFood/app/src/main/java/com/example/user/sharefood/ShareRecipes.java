package com.example.user.sharefood;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ShareRecipes extends AppCompatActivity {
    Button shareRecipes;
    EditText textIngredients , textPreparation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_recipes);

        shareRecipes = findViewById(R.id.btn_share_recipes);
        textIngredients = findViewById(R.id.txt_ingredients);
        textPreparation =  findViewById(R.id.txt_preparation);



        shareRecipes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ingredients , preparation;

                ingredients = textIngredients.getText().toString();
                preparation = textPreparation.getText().toString();

                Intent shareRecipesIntent = new Intent(Intent.ACTION_SEND);
                shareRecipesIntent.putExtra(Intent.EXTRA_TEXT , "The Ingredients is: \n" + ingredients + "\n\n" + "The Preparation is: \n" + preparation);
                shareRecipesIntent.setType("text/plain");
                startActivity(shareRecipesIntent);
            }
        });
    }
}





